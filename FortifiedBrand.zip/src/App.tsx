/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Code2, UploadCloud, FileCode2, CheckCircle2 } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center justify-center p-6 font-sans">
      <main className="w-full max-w-lg bg-white border border-slate-200/80 rounded-2xl p-8 shadow-sm text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-2xl border border-slate-200 flex items-center justify-center mx-auto mb-6 text-slate-600">
          <UploadCloud className="w-8 h-8 stroke-[1.75]" />
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium mb-4">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Workspace Ready</span>
        </div>

        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 mb-2">
          Empty Website
        </h1>

        <p className="text-sm text-slate-500 leading-relaxed mb-8">
          This project is clean and configured. Upload your code files or prompt your changes to start building.
        </p>

        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/60 text-left text-xs text-slate-600 space-y-2.5">
          <div className="flex items-center gap-2 font-medium text-slate-700">
            <FileCode2 className="w-4 h-4 text-slate-500" />
            <span>Getting Started:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-500 pl-1">
            <li>Paste or upload your source files directly</li>
            <li>Describe the changes or features you want to add</li>
            <li>Your application preview will update automatically</li>
          </ul>
        </div>
      </main>

      <footer className="mt-8 text-xs text-slate-400 flex items-center gap-1.5">
        <Code2 className="w-3.5 h-3.5" />
        <span>Ready for code upload</span>
      </footer>
    </div>
  );
}

