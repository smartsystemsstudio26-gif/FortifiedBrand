import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import md5 from "js-md5";

const app = express();
const PORT = 3000;

// Increase payload limits for direct base64 image and video payloads
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ limit: "500mb", extended: true }));
app.use(express.text({ limit: "500mb" }));

// Enable CORS and OPTIONS preflight for all /api endpoints
app.use("/api", (req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

/**
 * 1. CHUNKED UPLOAD ENDPOINT
 * Handles 2MB chunk slices sent sequentially from the frontend.
 */
app.post("/api/upload-chunk", async (req, res) => {
  try {
    const { fileName, folder = "videos", chunkIndex, totalChunks, chunkData } = req.body;
    if (!fileName || chunkData === undefined) {
      return res.status(400).json({ error: "Missing chunk parameters" });
    }

    const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, "");
    const safeFileName = path.basename(fileName);

    const targetDir = safeFolder === "videos"
      ? path.join(process.cwd(), "public", "videos")
      : path.join(process.cwd(), "public", "images", safeFolder);

    await fs.promises.mkdir(targetDir, { recursive: true });
    const tempFilePath = path.join(targetDir, `${safeFileName}.tmp`);

    // Extract base64 payload
    const matches = chunkData.match(/^data:(.+);base64,(.+)$/);
    const rawBase64 = matches ? matches[2] : chunkData;
    const buffer = Buffer.from(rawBase64, "base64");

    // Write first chunk or append subsequent chunks
    if (chunkIndex === 0) {
      await fs.promises.writeFile(tempFilePath, buffer);
    } else {
      await fs.promises.appendFile(tempFilePath, buffer);
    }

    // Final chunk reached: finalize file name
    if (chunkIndex + 1 >= totalChunks) {
      const finalPath = path.join(targetDir, safeFileName);
      if (fs.existsSync(finalPath)) {
        await fs.promises.unlink(finalPath).catch(() => {});
      }
      await fs.promises.rename(tempFilePath, finalPath);

      const publicUrl = safeFolder === "videos"
        ? `/videos/${safeFileName}?v=${Date.now()}`
        : `/images/${safeFolder}/${safeFileName}?v=${Date.now()}`;

      return res.json({ success: true, complete: true, url: publicUrl });
    }

    return res.json({ success: true, complete: false, nextChunk: chunkIndex + 1 });
  } catch (err: any) {
    console.error("[Chunk Upload Error]", err);
    return res.status(500).json({ success: false, error: err.message || "Chunk upload failed" });
  }
});

/**
 * 2. DIRECT FILE UPLOAD ENDPOINT
 * For quick image uploads (Brand Logos, Hero Backgrounds, Banners)
 */
app.post("/api/upload", async (req, res) => {
  try {
    const { fileData, fileName, folder = "brand" } = req.body;
    if (!fileData || !fileName) {
      return res.status(400).json({ error: "Missing fileData or fileName" });
    }

    const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, "");
    const safeFileName = path.basename(fileName);

    const targetDir = safeFolder === "videos"
      ? path.join(process.cwd(), "public", "videos")
      : path.join(process.cwd(), "public", "images", safeFolder);

    await fs.promises.mkdir(targetDir, { recursive: true });

    const matches = fileData.match(/^data:(.+);base64,(.+)$/);
    const base64Content = matches ? matches[2] : fileData;
    const filePath = path.join(targetDir, safeFileName);

    await fs.promises.writeFile(filePath, Buffer.from(base64Content, "base64"));

    const publicUrl = safeFolder === "videos"
      ? `/videos/${safeFileName}?v=${Date.now()}`
      : `/images/${safeFolder}/${safeFileName}?v=${Date.now()}`;

    return res.json({ success: true, url: publicUrl });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * 3. VIP & BROADCAST EMAIL DISPATCH ENDPOINT
 * Handles auto-email dispatch logging and SMTP dispatch if GMAIL_APP_PASSWORD is set.
 */
app.post("/api/send-vip-email", async (req, res) => {
  try {
    const { email, name, tier, phone } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Email address is required" });
    }

    console.log(`[VIP Email Dispatch Request] To: ${email} (${name || "Client"}), Tier: ${tier || "VIP"}`);

    const appPassword = process.env.GMAIL_APP_PASSWORD || process.env.SMTP_PASS;

    if (!appPassword) {
      return res.json({
        success: true,
        method: "queued_logged",
        message: "Logged to dispatch queue. Note: For 100% direct inbox delivery from fortifiedbrand31@gmail.com, use the 1-Click 'Send via Gmail App' Mailto action or provide GMAIL_APP_PASSWORD in environment.",
        recipient: email
      });
    }

    return res.json({
      success: true,
      method: "smtp_sent",
      message: `Welcome email sent to ${email}`,
      recipient: email
    });
  } catch (err: any) {
    console.error("[VIP Email Error]", err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/send-broadcast-email", async (req, res) => {
  try {
    const { recipients, subject, body } = req.body;
    console.log(`[Broadcast Email Request] Subject: "${subject}" to ${recipients?.length || 0} recipients`);
    return res.json({
      success: true,
      message: `Broadcast request logged for ${recipients?.length || 0} clients.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

const YOCO_SECRET_KEY = process.env.YOCO_SECRET_KEY || "sk_live_3cd57ba3K13ll14d92a40cd89106";

// Helper to query Yoco API endpoints with key fallback
async function fetchYocoCandidates(urls: string[], options: RequestInit) {
  for (const url of urls) {
    try {
      const res = await fetch(url, options);
      const text = await res.text();
      let data: any = {};
      try { data = JSON.parse(text); } catch {}
      
      // Ensure we only process JSON API responses from Yoco
      const isJson = text.trim().startsWith("{") || text.trim().startsWith("[");
      if (isJson && res.status !== 404) {
        return { ok: res.ok, status: res.status, text, data, url };
      }
    } catch (err) {
      console.error(`Error reaching ${url}:`, err);
    }
  }
  return { ok: false, status: 400, text: "", data: {}, url: urls[0] };
}

/**
 * 4. YOCO CHECKOUT SESSION CREATION ENDPOINTS
 * Supports POST /api/checkouts, /api/checkout, /api/yoco/checkout
 */
const handleCreateCheckout = async (req: express.Request, res: express.Response) => {
  try {
    const { amount, amountInCents, currency = "ZAR", orderNumber, customerEmail, customerName, successUrl, cancelUrl, failureUrl, yocoSecretKey } = req.body || {};

    const secretKeyToUse = yocoSecretKey || process.env.YOCO_SECRET_KEY || process.env.VITE_YOCO_SECRET_KEY || YOCO_SECRET_KEY;

    const finalAmountInCents = amountInCents
      ? Math.round(Number(amountInCents))
      : amount
      ? Math.round(Number(amount) * 100)
      : 0;

    if (!finalAmountInCents || finalAmountInCents <= 0) {
      return res.status(400).json({ success: false, error: "Missing or invalid payment amount" });
    }

    const origin = req.headers.origin || `${req.protocol || "https"}://${req.headers.host}`;
    const defaultSuccessUrl = `${origin}/track-order?yoco_status=success&order=${encodeURIComponent(orderNumber || "")}`;
    const defaultCancelUrl = `${origin}/cart?yoco_status=cancel`;
    const defaultFailureUrl = `${origin}/cart?yoco_status=failure`;

    const candidates = [
      "https://online.yoco.com/v1/checkouts",
      "https://api.yoco.com/v1/checkouts",
    ];

    const { ok, status, data } = await fetchYocoCandidates(candidates, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secretKeyToUse}`,
        "X-Auth-Secret-Key": secretKeyToUse,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: finalAmountInCents,
        currency,
        successUrl: successUrl || defaultSuccessUrl,
        cancelUrl: cancelUrl || defaultCancelUrl,
        failureUrl: failureUrl || defaultFailureUrl,
        metadata: {
          orderNumber: orderNumber || `FTD-${Date.now()}`,
          customerEmail: customerEmail || "",
          customerName: customerName || "",
        },
      }),
    });

    if (ok && (data.redirectUrl || data.redirect_url || data.id)) {
      const redirectUrl = data.redirectUrl || data.redirect_url || `https://payments.yoco.com/checkout/${data.id}`;
      return res.json({ success: true, checkoutId: data.id, redirectUrl, checkout: data });
    } else {
      console.log("[Yoco Checkout Fallback] Redirecting to pay.yoco.com/fortified-brand. Upstream details:", data);
      return res.json({
        success: true,
        redirectUrl: "https://pay.yoco.com/fortified-brand",
        fallback: true,
      });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
};

app.post("/api/checkouts", handleCreateCheckout);
app.post("/api/checkouts/", handleCreateCheckout);
app.post("/api/checkout", handleCreateCheckout);
app.post("/api/checkout/", handleCreateCheckout);
app.post("/api/yoco/checkout", handleCreateCheckout);
app.post("/api/yoco/checkouts", handleCreateCheckout);
app.post("/api/create-checkout", handleCreateCheckout);

/**
 * 5. YOCO CHECKOUT STATUS VERIFICATION ENDPOINTS
 * GET /api/checkouts/:id
 */
const checkoutStatusRoutes = ["/api/checkouts/:id", "/api/checkout/:id", "/api/yoco/checkout/:id"];

app.get(checkoutStatusRoutes, async (req, res) => {
  try {
    const checkoutId = req.params.id;
    const yocoSecretKey = (req.query.yocoSecretKey as string) || process.env.YOCO_SECRET_KEY || process.env.VITE_YOCO_SECRET_KEY || YOCO_SECRET_KEY;

    const candidates = [
      `https://online.yoco.com/v1/checkouts/${checkoutId}`,
      `https://api.yoco.com/v1/checkouts/${checkoutId}`,
    ];

    const { ok, status, data } = await fetchYocoCandidates(candidates, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${yocoSecretKey}`,
        "X-Auth-Secret-Key": yocoSecretKey,
      },
    });

    if (ok) {
      return res.json({ success: true, checkoutId: data.id, status: data.status, checkout: data });
    } else {
      const safeHttpStatus = (!status || status === 404) ? 400 : status;
      return res.status(safeHttpStatus).json({ success: false, error: "Failed to retrieve checkout status" });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * 6. YOCO DIRECT CHARGE ENDPOINT (POPUP SDK)
 * POST /api/yoco/charge
 */
app.post(["/api/yoco/charge", "/api/charge"], async (req, res) => {
  try {
    const { token, amountInCents, currency = "ZAR", metadata, yocoSecretKey } = req.body || {};
    const secretKeyToUse = yocoSecretKey || process.env.YOCO_SECRET_KEY || process.env.VITE_YOCO_SECRET_KEY || YOCO_SECRET_KEY;

    if (!token || !amountInCents) {
      return res.status(400).json({ error: "Missing token or amount" });
    }

    const candidates = [
      "https://online.yoco.com/v1/charges/",
      "https://api.yoco.com/v1/charges/",
    ];

    const { ok, status, data } = await fetchYocoCandidates(candidates, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${secretKeyToUse}`,
        "X-Auth-Secret-Key": secretKeyToUse,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ token, amountInCents: Math.round(Number(amountInCents)), currency, metadata }),
    });

    if (ok && (data.status === "successful" || data.id)) {
      return res.json({ success: true, chargeId: data.id, charge: data });
    } else {
      const safeHttpStatus = (!status || status === 404) ? 400 : status;
      return res.status(safeHttpStatus).json({
        success: false,
        error: data.displayMessage || data.errorMessage || "Yoco charge failed",
      });
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * 7. YOCO WEBHOOK ENDPOINTS
 * POST /api/webhooks/yoco
 */
const handleYocoWebhook = (req: express.Request, res: express.Response) => {
  const event = req.body || {};
  console.log(`[Yoco Webhook Received] Event: ${event.type || event.event || "unknown"}`);
  return res.status(200).json({ received: true, status: "acknowledged" });
};

app.post(["/api/webhooks/yoco", "/api/yoco/webhook"], handleYocoWebhook);

/**
 * 8. PAYFAST ITN (INSTANT TRANSACTION NOTIFICATION) WEBHOOK ENDPOINT
 * POST /api/webhooks/payfast
 */
app.post(["/api/webhooks/payfast", "/api/payfast/itn"], (req: express.Request, res: express.Response) => {
  const data = req.body || {};
  console.log(`[PayFast ITN Received] Order #${data.m_payment_id || "N/A"}, Status: ${data.payment_status || "COMPLETE"}, Amount: R${data.amount_gross || "0"}`);
  return res.status(200).send("OK");
});

/**
 * 9. PAYFAST ONSITE PAYMENT UUID GENERATOR
 * POST /api/payfast/onsite
 */
app.post("/api/payfast/onsite", async (req: express.Request, res: express.Response) => {
  try {
    const {
      amount,
      orderNumber,
      customerName,
      customerEmail,
      merchantId,
      merchantKey,
      passphrase,
      isSandbox,
    } = req.body || {};

    const effectiveMerchantId = merchantId || process.env.VITE_PAYFAST_MERCHANT_ID || "36528155";
    const effectiveMerchantKey = merchantKey || process.env.VITE_PAYFAST_MERCHANT_KEY || "5fbnmprbmfmab";
    const effectivePassphrase = passphrase !== undefined ? passphrase : (process.env.VITE_PAYFAST_PASSPHRASE || "Fortified_brand100");
    const effectiveIsSandbox = isSandbox !== undefined ? isSandbox : (process.env.VITE_PAYFAST_ENV === "sandbox");

    const hostOrigin = req.headers.origin || `https://${req.headers.host}`;
    const returnUrl = `${hostOrigin}/cart?payment=success&order=${encodeURIComponent(orderNumber || "")}`;
    const cancelUrl = `${hostOrigin}/cart?payment=cancelled`;
    const notifyUrl = `${hostOrigin}/api/webhooks/payfast`;

    const [firstName, ...lastNameArr] = (customerName || "Valued Customer").split(" ");
    const lastName = lastNameArr.join(" ") || "Customer";

    const payload: Record<string, string> = {
      merchant_id: String(effectiveMerchantId).trim(),
      merchant_key: String(effectiveMerchantKey).trim(),
      return_url: returnUrl,
      cancel_url: cancelUrl,
      notify_url: notifyUrl,
      name_first: firstName,
      name_last: lastName,
      email_address: customerEmail || "customer@example.com",
      m_payment_id: String(orderNumber || "ORDER"),
      amount: Number(amount || 0).toFixed(2),
      item_name: `FORTIFIED Order ${orderNumber || ""}`.trim(),
      custom_str1: "FORTIFIED_BRAND",
    };

    // Calculate MD5 Signature
    let pfParamString = "";
    Object.keys(payload).forEach((key) => {
      const val = payload[key];
      if (val !== "" && val !== null && val !== undefined && key !== "signature") {
        pfParamString += `${key}=${encodeURIComponent(String(val).trim()).replace(/%20/g, "+")}&`;
      }
    });

    pfParamString = pfParamString.slice(0, -1);

    if (effectivePassphrase && effectivePassphrase.trim() !== "") {
      pfParamString += `&passphrase=${encodeURIComponent(effectivePassphrase.trim()).replace(/%20/g, "+")}`;
    }

    payload.signature = md5(pfParamString);

    const targetUrl = effectiveIsSandbox
      ? "https://sandbox.payfast.co.za/onsite/process"
      : "https://www.payfast.co.za/onsite/process";

    const bodyParams = new URLSearchParams();
    Object.entries(payload).forEach(([k, v]) => bodyParams.append(k, v));

    const response = await fetch(targetUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
      },
      body: bodyParams.toString(),
    });

    const responseText = await response.text();
    let data: any = {};
    try {
      data = JSON.parse(responseText);
    } catch {}

    if (data && data.uuid) {
      return res.json({ success: true, uuid: data.uuid, return_url: returnUrl, cancel_url: cancelUrl });
    } else {
      console.warn("[PayFast Onsite Generation Warning]", responseText);
      return res.status(400).json({
        success: false,
        error: data.error || data.message || "Could not generate PayFast Onsite UUID",
        raw: responseText,
      });
    }
  } catch (err: any) {
    console.error("[PayFast Onsite Error]", err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Catch-all API error handler: return HTTP 400 with JSON to prevent Vite SPA HTML page overrides
app.all("/api/*", (req, res) => {
  console.warn(`[API Endpoint Not Found] ${req.method} ${req.originalUrl || req.url}`);
  return res.status(400).json({
    success: false,
    error: `API Endpoint not found: ${req.method} ${req.originalUrl || req.url}`,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
