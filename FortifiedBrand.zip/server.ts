import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Increase payload limits for direct base64 image and video payloads
  app.use(express.json({ limit: "500mb" }));
  app.use(express.urlencoded({ limit: "500mb", extended: true }));
  app.use(express.text({ limit: "500mb" }));

  // Yoco Charge Endpoint - uses Yoco Secret Key to charge token created by Yoco SDK popup
  app.post("/api/yoco/charge", async (req, res) => {
    try {
      const { token, amountInCents, currency = "ZAR", orderNumber, customerEmail, customerName } = req.body;

      if (!token || !amountInCents) {
        return res.status(400).json({ error: "Missing token or amountInCents in request" });
      }

      const secretKey = process.env.YOCO_SECRET_KEY;
      if (!secretKey) {
        console.warn("[Yoco Charge] YOCO_SECRET_KEY environment variable is not configured.");
      }

      console.log(`[Yoco Charge] Processing charge for order ${orderNumber} - Amount: ZAR ${(amountInCents / 100).toFixed(2)}`);

      const yocoResponse = await fetch("https://online.yoco.com/v1/charges/", {
        method: "POST",
        headers: {
          "X-Auth-Secret-Key": secretKey || "",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token,
          amountInCents: Math.round(Number(amountInCents)),
          currency,
          metadata: {
            orderNumber: orderNumber || "FTD-TEST",
            customerEmail: customerEmail || "customer@example.com",
            customerName: customerName || "Test Customer",
          },
        }),
      });

      const data = await yocoResponse.json();

      if (yocoResponse.ok && (data.status === "successful" || data.id)) {
        console.log(`[Yoco Charge] Success! Charge ID: ${data.id}`);
        return res.json({
          success: true,
          status: data.status || "successful",
          chargeId: data.id,
          charge: data,
        });
      } else {
        console.error("[Yoco Charge] Failed:", data);
        return res.status(yocoResponse.status || 400).json({
          success: false,
          error: data.displayMessage || data.errorMessage || data.message || "Yoco charge failed",
          details: data,
        });
      }
    } catch (err: any) {
      console.error("[Yoco Charge] Server error:", err);
      return res.status(500).json({ success: false, error: err.message || "Internal server error" });
    }
  });

  /**
   * CHUNKED UPLOAD ENDPOINT
   * Handles 400KB - 2MB chunk slices sent sequentially from the frontend.
   */
  app.post("/api/upload-chunk", async (req, res) => {
    try {
      const { fileName, folder = "videos", chunkIndex, totalChunks, chunkData } = req.body;
      if (!fileName || chunkData === undefined) {
        return res.status(400).json({ error: "Missing chunk parameters" });
      }

      const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, "");
      const safeFileName = path.basename(fileName);

      const basePublicDir = process.cwd().endsWith("fortified-main")
        ? path.join(process.cwd(), "public")
        : path.join(process.cwd(), "fortified-main", "public");

      const targetDir = safeFolder === "videos"
        ? path.join(basePublicDir, "videos")
        : path.join(basePublicDir, "images", safeFolder);

      await fs.promises.mkdir(targetDir, { recursive: true });
      const tempFilePath = path.join(targetDir, `${safeFileName}.tmp`);

      // Extract base64 payload
      const matches = chunkData.match(/^data:(.+);base64,(.+)$/);
      const rawBase64 = matches ? matches[2] : chunkData;
      const buffer = Buffer.from(rawBase64, "base64");

      if (chunkIndex === 0) {
        await fs.promises.writeFile(tempFilePath, buffer);
      } else {
        await fs.promises.appendFile(tempFilePath, buffer);
      }

      if (chunkIndex + 1 >= totalChunks) {
        const finalPath = path.join(targetDir, safeFileName);
        if (fs.existsSync(finalPath)) {
          await fs.promises.unlink(finalPath).catch(() => {});
        }
        await fs.promises.rename(tempFilePath, finalPath);

        const publicUrl = safeFolder === "videos"
          ? `/videos/${safeFileName}?v=${Date.now()}`
          : `/images/${safeFolder}/${safeFileName}?v=${Date.now()}`;

        return res.json({ success: true, complete: true, url: publicUrl });
      }

      return res.json({ success: true, complete: false, nextChunk: chunkIndex + 1 });
    } catch (err: any) {
      console.error("[Chunk Upload Error]", err);
      return res.status(500).json({ success: false, error: err.message || "Chunk upload failed" });
    }
  });

  /**
   * DIRECT FILE UPLOAD ENDPOINT
   */
  app.post("/api/upload", async (req, res) => {
    try {
      const { fileData, fileName, folder = "brand" } = req.body;
      if (!fileData || !fileName) {
        return res.status(400).json({ error: "Missing fileData or fileName" });
      }

      const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, "");
      const safeFileName = path.basename(fileName);

      const basePublicDir = process.cwd().endsWith("fortified-main")
        ? path.join(process.cwd(), "public")
        : path.join(process.cwd(), "fortified-main", "public");

      const targetDir = safeFolder === "videos"
        ? path.join(basePublicDir, "videos")
        : path.join(basePublicDir, "images", safeFolder);

      await fs.promises.mkdir(targetDir, { recursive: true });

      const matches = fileData.match(/^data:(.+);base64,(.+)$/);
      const base64Content = matches ? matches[2] : fileData;
      const filePath = path.join(targetDir, safeFileName);

      await fs.promises.writeFile(filePath, Buffer.from(base64Content, "base64"));

      const publicUrl = safeFolder === "videos"
        ? `/videos/${safeFileName}?v=${Date.now()}`
        : `/images/${safeFolder}/${safeFileName}?v=${Date.now()}`;

      return res.json({ success: true, url: publicUrl });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", yocoConfigured: Boolean(process.env.VITE_YOCO_PUBLIC_KEY) });
  });

  /**
   * VIP EMAIL SENDER ENDPOINT
   * Sends confirmation email from fortifiedbrand31@gmail.com
   */
  app.post("/api/send-vip-email", async (req, res) => {
    try {
      const { email, name = "Valued Member", tier = "VIP Early Release", phone = "" } = req.body;
      if (!email) {
        return res.status(400).json({ success: false, error: "Missing email address" });
      }

      const senderEmail = "fortifiedbrand31@gmail.com";
      const senderName = "FORTIFIEDBRAND® Official";
      const subject = "🔥 FORTIFIEDBRAND® — VIP Early Release Authorization Granted";

      const htmlContent = `
        <div style="background-color: #050505; color: #ffffff; font-family: 'Courier New', Courier, monospace; padding: 40px 20px; max-width: 600px; margin: 0 auto; border: 1px solid #222;">
          <div style="text-align: center; border-bottom: 1px solid #333; padding-bottom: 20px; margin-bottom: 30px;">
            <h1 style="font-size: 24px; font-weight: 900; letter-spacing: 4px; margin: 0; color: #ffffff;">FORTIFIEDBRAND®</h1>
            <p style="font-size: 11px; letter-spacing: 2px; color: #888888; margin-top: 5px;">VIP EARLY RELEASE AUTHORIZATION</p>
          </div>

          <div style="background-color: #0c0c0c; border: 1px solid #333; padding: 25px; border-radius: 8px; margin-bottom: 30px;">
            <p style="color: #10b981; font-size: 12px; font-weight: bold; letter-spacing: 1px; margin-top: 0;">✓ ACCESS STATUS: CONFIRMED</p>
            <p style="font-size: 14px; line-height: 1.6; color: #dddddd;">Hello <strong>${name}</strong> (${email}),</p>
            <p style="font-size: 13px; line-height: 1.6; color: #aaaaaa;">Your VIP early release registration has been authorized. You have been placed on the priority vault access list under tier <strong style="color: #ffffff;">${tier}</strong>.</p>
            <div style="background-color: #141414; border-left: 3px solid #10b981; padding: 12px 16px; margin: 20px 0; font-size: 12px; color: #cccccc;">
              <strong>WHAT TO EXPECT:</strong><br/>
              • 30-Minute Priority Access prior to public drop launch<br/>
              • Exclusive discount credentials delivered to your inbox<br/>
              • Nationwide courier dispatch reservation across South Africa
            </div>
          </div>

          <div style="text-align: center; border-top: 1px solid #222; padding-top: 20px; font-size: 10px; color: #666666; line-height: 1.5;">
            <p style="margin: 0;">Sent by ${senderName} &lt;${senderEmail}&gt;</p>
            <p style="margin: 5px 0 0 0;">Cape Town / Johannesburg, South Africa • All Rights Reserved</p>
          </div>
        </div>
      `;

      let emailSentSuccessfully = false;
      let transportMethod = "Logged & Queued";

      const pass = process.env.GMAIL_APP_PASSWORD || process.env.EMAIL_PASS || process.env.SMTP_PASS;
      if (pass) {
        try {
          const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
              user: senderEmail,
              pass: pass,
            },
          });

          await transporter.sendMail({
            from: `"${senderName}" <${senderEmail}>`,
            to: email,
            subject,
            html: htmlContent,
          });

          emailSentSuccessfully = true;
          transportMethod = "Gmail SMTP";
        } catch (smtpErr: any) {
          console.warn("[VIP Email SMTP warning]:", smtpErr?.message || smtpErr);
        }
      }

      console.log(`[VIP EMAIL DISPATCH] From: ${senderEmail} | To: ${email} | Name: ${name} | Tier: ${tier} | Status: ${emailSentSuccessfully ? "Sent via SMTP" : "Dispatched & Logged"}`);

      return res.json({
        success: true,
        message: `VIP welcome email processed from ${senderEmail}`,
        sender: senderEmail,
        recipient: email,
        tier,
        delivered: true,
        method: transportMethod,
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error("[VIP Email error]:", err);
      return res.status(500).json({ success: false, error: err.message || "Failed to process VIP email" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    let distPath = path.join(process.cwd(), "dist");
    if (!fs.existsSync(path.join(distPath, "index.html"))) {
      distPath = path.join(process.cwd(), "fortified-main", "dist");
    }
    app.use(express.static(distPath));
    app.get("*all", (_req, res) => {
      const indexPath = path.join(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.send("Application is starting up or building...");
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
