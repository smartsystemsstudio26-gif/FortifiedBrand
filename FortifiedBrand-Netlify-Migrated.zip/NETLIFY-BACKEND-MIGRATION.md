# FortifiedBrand — Netlify backend migration

This version removes the legacy Express server from the Netlify build and moves the payment API routes to Netlify Functions.

## What changed

- Removed the legacy `server.ts` from the deployment build.
- `npm run build` now builds the Vite frontend only.
- Added Netlify Functions for Yoco checkout/status/webhook and PayFast onsite/form/ITN endpoints.
- Payment secrets are no longer read from localStorage, Firestore, React state, or browser request bodies.
- The PayFast browser form is now generated and signed server-side; PayFast still requires its merchant key in the form payload, while the passphrase remains server-only.
- Yoco uses hosted Checkout API flow rather than sending a secret key from the browser.
- Admin payment settings no longer expose Yoco secret, PayFast merchant key, or PayFast passphrase.

## Netlify environment variables

Create these in **Project configuration → Environment variables**. Secret variables should include the **Functions** scope. Netlify applies updated environment variables on the next deploy.

```text
YOCO_SECRET_KEY=...
YOCO_WEBHOOK_SECRET=...
PAYFAST_MERCHANT_ID=...
PAYFAST_MERCHANT_KEY=...
PAYFAST_PASSPHRASE=...
PAYFAST_ENV=live
VITE_YOCO_PUBLIC_KEY=...
```

Do not put the actual values into GitHub.

## Important credential rotation

The original uploaded project contained payment credentials in source/local settings. Treat those credentials as exposed and rotate them in Yoco/PayFast before production. Do not reuse the old secret values merely because they are present in the old project.

## Netlify settings

```text
Branch: main
Base directory: fortified-main
Build command: npm run build
Publish directory: dist
Functions directory: netlify/functions
Node: 20
```

The functions directory is outside `dist`, as recommended for Netlify Functions.

## Payment webhook setup

Yoco webhook URL:

```text
https://YOUR-DOMAIN.com/api/webhooks/yoco
```

PayFast ITN URL:

```text
https://YOUR-DOMAIN.com/api/webhooks/payfast
```

PayFast ITN validation is implemented for signature, merchant ID and PayFast server confirmation. Order-status persistence is intentionally not guessed here because the current project does not have a secure server-side order repository.

## Uploads

The legacy Express upload endpoints wrote files into `public/`. That is not appropriate for Netlify Functions, and Netlify synchronous Functions have a 6 MB buffered request/response limit. Large media uploads should be moved to Firebase Storage or another object-storage service in the next migration phase.
